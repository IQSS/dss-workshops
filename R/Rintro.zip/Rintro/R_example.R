# My Brilliant Paper

# R file

# This is an R file document. It is a simple text document that can contain both R code and commented text. R files cannot be converted into HTML, PDF, or MS Word documents. Comments start with a '#' prefix, while code is not written inside a 'chunk'. 

summary(cars)

# Including Plots

# Plots are not embedded, for example:

plot(pressure)