This directory contains baby name statistics from England and Wales.

Data provided by the Office for National Statistics and are licensed under the 
Open Government Licence (http://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/)

Data retrieved October 5th 2016 from 
https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/livebirths/datasets/babynamesenglandandwalesbabynamesstatisticsboys
and
https://www.ons.gov.uk/peoplepopulationandcommunity/birthsdeathsandmarriages/livebirths/datasets/babynamesenglandandwalesbabynamesstatisticsboys
